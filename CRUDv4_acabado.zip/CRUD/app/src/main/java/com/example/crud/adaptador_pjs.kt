package com.example.crud

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.RatingBar
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.storage.FirebaseStorage
import java.io.Serializable

class adaptador_pjs (private val lista_pj:List<PJ>): RecyclerView.Adapter<adaptador_pjs.pjViewHolder>() {

    private lateinit var contexto: Context

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): pjViewHolder {
        val vista_item= LayoutInflater.from(parent.context).inflate(R.layout.rv_pjs,parent, false)
        //Para poder hacer referencia al contexto de la aplicacion desde otros metodos de la clase
        contexto=parent.context

        return pjViewHolder(vista_item)
    }
    override fun onBindViewHolder(holder: pjViewHolder, position: Int) {
        val item_actual=lista_pj[position]
        holder.nombre.text=item_actual.nombre
        holder.raza.text="Raza: "+item_actual.raza.toString()
        holder.fuerza.text="STR: "+item_actual.fuerza.toString()
        holder.const.text="CONS: "+item_actual.constitucion.toString()
        holder.dex.text="DEX: "+item_actual.destreza.toString()
        holder.int.text="INT: "+item_actual.inteligencia.toString()
        holder.sab.text="WIS: "+item_actual.sabiduria.toString()
        holder.car.text="CAR: "+item_actual.carisma.toString()
        holder.create.text="Creado: " +item_actual.creacion.toString()
        holder.popu.rating=item_actual.rating?.toFloat()!!
        Glide.with(contexto).load(item_actual.url_avatar).into(holder.miniatura)

        holder.editar.setOnClickListener(View.OnClickListener {
            val actividad = Intent(contexto,editar::class.java)
            actividad.putExtra("heroe", item_actual as Serializable)
            contexto.startActivity (actividad)
        })

        holder.borrar.setOnClickListener(View.OnClickListener {
            val db_ref= FirebaseDatabase.getInstance().getReference()
            val sto_ref= FirebaseStorage.getInstance().getReference()

            sto_ref.child("personoaje").child("heroe").child(item_actual.id!!).delete()
            db_ref.child("personaje").child("heroe").child(item_actual.id!!).removeValue()

            Toast.makeText(contexto, "Personaje borrado", Toast.LENGTH_SHORT).show()
       })

    }

    override fun getItemCount(): Int = lista_pj.size
    class pjViewHolder(itemView: View): RecyclerView.ViewHolder(itemView){
        val miniatura: ImageView = itemView.findViewById(R.id.iv_avatar)
        val nombre: TextView = itemView.findViewById(R.id.tv_nombre)
        val create:TextView = itemView.findViewById(R.id.tv_creacion)
        val raza: TextView =  itemView.findViewById(R.id.tv_raza)
        val fuerza: TextView =  itemView.findViewById(R.id.tv_str2)
        val const: TextView =  itemView.findViewById(R.id.tv_cons2)
        val dex: TextView =  itemView.findViewById(R.id.tv_dex2)
        val int: TextView =  itemView.findViewById(R.id.tv_int2)
        val sab: TextView =  itemView.findViewById(R.id.tv_sab2)
        val car: TextView =  itemView.findViewById(R.id.tv_car2)
        val popu: RatingBar=itemView.findViewById(R.id.tv_popularidad)
        val editar: ImageView =itemView.findViewById(R.id.editar)
        val borrar: ImageView =itemView.findViewById(R.id.img_borrar)

    }
}
//var id:String?=null,
//var nombre:String?=null,
//var str:Int?=null,
//var dex:Int?=null,
//var const:Int?=null,
//var int:Int?=null,
//var wis:Int?=null,
//var crs:Int?=null,
//var rating:Int?=null