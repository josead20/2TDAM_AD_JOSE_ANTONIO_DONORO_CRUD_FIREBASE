package com.example.crud

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import com.bumptech.glide.Glide
import com.google.firebase.database.*
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.CountDownLatch

class editar : AppCompatActivity() {

    lateinit var in_name: EditText
    lateinit var in_raza: EditText
    lateinit var in_str: EditText
    lateinit var in_cons: EditText
    lateinit var in_dex: EditText
    lateinit var in_int: EditText
    lateinit var in_wis: EditText
    lateinit var in_crs: EditText
    lateinit var in_poular: RatingBar
    lateinit var image_avatar: ImageView
    lateinit var modificar:Button

    private lateinit var pojo_pj:PJ

    private var url_avatar: Uri?=null
    private lateinit var db_ref: DatabaseReference
    private lateinit var sto_ref: StorageReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_editar)

        pojo_pj=intent.getSerializableExtra("heroe") as PJ

        in_name=findViewById(R.id.input_nombre)
        in_raza=findViewById(R.id.input_raza)
        in_str=findViewById(R.id.input_str)
        in_cons=findViewById(R.id.input_cons)
        in_dex=findViewById(R.id.input_dex)
        in_int=findViewById(R.id.input_int)
        in_wis=findViewById(R.id.input_wis)
        in_crs=findViewById(R.id.input_car)
        in_poular=findViewById(R.id.ratin_popu)
        image_avatar=findViewById((R.id.iv_avatar_crear))

        in_name.setText(pojo_pj.nombre)
        in_raza.setText(pojo_pj.raza)
        in_str.setText(pojo_pj.fuerza.toString())
        in_cons.setText(pojo_pj.constitucion.toString())
        in_dex.setText(pojo_pj.destreza.toString())
        in_int.setText(pojo_pj.inteligencia.toString())
        in_wis.setText(pojo_pj.sabiduria.toString())
        in_crs.setText(pojo_pj.carisma.toString())
        in_poular.rating=pojo_pj.rating!!

        Glide.with(applicationContext).load(pojo_pj.url_avatar).into(image_avatar)

        db_ref= FirebaseDatabase.getInstance().getReference()
        sto_ref= FirebaseStorage.getInstance().getReference()
        modificar=findViewById(R.id.btn_modi_pj) as Button

        image_avatar.setOnClickListener(View.OnClickListener {
            obtener_url.launch("image/*")
        })

        val currentDate = pojo_pj.creacion.toString()

        modificar.setOnClickListener{
            var url_avatar_firebase:String?=pojo_pj.url_avatar
                GlobalScope.launch(Dispatchers.IO) {
                    if(!in_name.text.toString().trim().equals(pojo_pj.nombre) && existe_pj(in_name.text.toString().trim())){
                        tostadaCorrutina("El Heroe ya existe")

                    }else{
                        if(url_avatar!=null){
                            url_avatar_firebase=editarAvatar(pojo_pj.id!!,url_avatar!!)
                        }
                    }

                    val url_firebase = sto_ref.child("personaje")
                        .child("heroe")
                        .child(pojo_pj.id!!)
                        .putFile(url_avatar!!)
                        .await().storage.downloadUrl.await()

                    editarPJ(pojo_pj.id!!,
                        in_name.text.toString().trim(),
                        in_raza.text.toString().trim(),
                        in_str.text.toString().toInt(),
                        in_cons.text.toString().toInt(),
                        in_dex.text.toString().toInt(),
                        in_int.text.toString().toInt(),
                        in_wis.text.toString().toInt(),
                        in_crs.text.toString().toInt(),
                        currentDate,
                        in_poular.rating.toFloat(),
                        url_avatar_firebase!!
                    )



                    tostadaCorrutina("Heroe modificado con exito")

                    val actividad = Intent(applicationContext, ver_pjs::class.java)
                    startActivity(actividad)
                }

        }
    }

    private suspend fun editarAvatar(id:String,imagen:Uri):String{
        var url_escudo_firebase:Uri?=null

        url_escudo_firebase=sto_ref.child("personajes").child("heroe").child(id)
            .putFile(imagen).await().storage.downloadUrl.await()

        return url_escudo_firebase.toString()
    }

    private suspend fun editarPJ(id:String,nombre:String,raza:String,fuerza:Int,cons:Int, dex:Int, int:Int, wis:Int,crs:Int,creacion:String, Popularidad:Float, url_firebase:String){
        val nuevo_pj= PJ(
            id,
            nombre,
            raza,
            fuerza,
            cons,
            dex,
            int,
            wis,
            crs,
            creacion,
            Popularidad,
            url_firebase


        )
        db_ref.child("personaje").child("heroe").child(id).setValue(nuevo_pj)

    }
    private val obtener_url= registerForActivityResult(ActivityResultContracts.GetContent()){
            uri:Uri?->
        if(uri==null){
            Toast.makeText(applicationContext,
                "No has seleccionado una imagen",
                Toast.LENGTH_SHORT).show()
        }else{
            //Recoger la uri para usarla al crear
            url_avatar=uri
            //Marcar en el imageView la imagen seleccionada
            image_avatar.setImageURI(url_avatar)

            Toast.makeText(applicationContext,
                "Imagen seleccionada correctamente",
                Toast.LENGTH_SHORT).show()
        }
    }

    private fun existe_pj(nombre:String):Boolean{
        var resultado:Boolean?=false

        val semaforo= CountDownLatch(1)
        db_ref.child("personajes")
            .child("heroe")
            .orderByChild("nombre")
            .equalTo(nombre)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if(snapshot.hasChildren()){
                        resultado=true;
                    }
                    semaforo.countDown()
                }

                override fun onCancelled(error: DatabaseError) {
                    println(error.message)
                }
            })

        semaforo.await();

        return resultado!!;
    }

    private suspend fun tostadaCorrutina(texto:String){
        runOnUiThread{
            Toast.makeText(
                applicationContext,
                texto,
                Toast.LENGTH_SHORT
            ).show()
        }
    }

}