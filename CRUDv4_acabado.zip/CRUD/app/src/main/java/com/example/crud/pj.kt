package com.example.crud

import java.io.Serializable

data class PJ (var id:String?=null,
               var nombre:String?=null,
               var raza:String?=null,
               var fuerza:Int?=null,
               var constitucion:Int?=null,
               var destreza:Int?=null,
               var inteligencia:Int?=null,
               var sabiduria:Int?=null,
               var carisma:Int?=null,
               var creacion:String?=null,
               var rating:Float?=null,
                var url_avatar:String?=null
):Serializable

