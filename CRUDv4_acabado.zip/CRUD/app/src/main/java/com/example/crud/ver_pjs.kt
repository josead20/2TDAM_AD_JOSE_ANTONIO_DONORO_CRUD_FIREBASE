package com.example.crud

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.database.*
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference


class ver_pjs : AppCompatActivity() {
    lateinit var btn_fuerza_max:Button
    lateinit var btn_fuerza_min:Button
    lateinit var recycler: RecyclerView
    lateinit var db_ref: DatabaseReference
    lateinit var sto_ref: StorageReference
    private lateinit var lista: ArrayList<PJ>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ver_pjs)
        btn_fuerza_max=findViewById(R.id.Fuerza_top)
        btn_fuerza_min=findViewById(R.id.Fuerza_bot)

        db_ref = FirebaseDatabase.getInstance().getReference()
        sto_ref = FirebaseStorage.getInstance().getReference()

        lista = ArrayList<PJ>()

        btn_fuerza_min.setOnClickListener{

            db_ref.child("personaje")
                .child("heroe")
                .orderByChild("fuerza")
                .addValueEventListener(object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        lista.clear()
                        snapshot.children.forEach { hijo: DataSnapshot? ->
                            val pojo_pj = hijo?.getValue(PJ::class.java)
                            lista.add(pojo_pj!!)
                        }
                        recycler.adapter?.notifyDataSetChanged()
                    }
                    override fun onCancelled(error: DatabaseError) {
                        println(error.message)
                    }
                })
            recycler=findViewById(R.id.lista)
            recycler.adapter=adaptador_pjs(lista)
            recycler.layoutManager= LinearLayoutManager(applicationContext)
            recycler.setHasFixedSize(true)
        }
        btn_fuerza_max.setOnClickListener{

            recycler.adapter=adaptador_pjs(lista.reversed())
        }

        //Consulta a la bd
        db_ref.child("personaje")
            .child("heroe")
            .addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    lista.clear()
                    snapshot.children.forEach { hijo: DataSnapshot? ->
                        val pojo_pj = hijo?.getValue(PJ::class.java)
                        lista.add(pojo_pj!!)
                    }
                    recycler.adapter?.notifyDataSetChanged()
                }
                override fun onCancelled(error: DatabaseError) {
                    println(error.message)
                }
            })
        recycler=findViewById(R.id.lista)
        recycler.adapter=adaptador_pjs(lista)
        recycler.layoutManager= LinearLayoutManager(applicationContext)
        recycler.setHasFixedSize(true)
    }
}