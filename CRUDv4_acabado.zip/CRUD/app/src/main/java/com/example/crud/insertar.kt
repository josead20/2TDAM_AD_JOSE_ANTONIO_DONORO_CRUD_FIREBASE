package com.example.crud

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import com.google.firebase.database.*
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import java.util.concurrent.CountDownLatch
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.tasks.await
import java.text.SimpleDateFormat
import java.util.*

class insertar : AppCompatActivity() {
    lateinit var in_name:EditText
    lateinit var in_raza:EditText
    lateinit var in_str:EditText
    lateinit var in_cons:EditText
    lateinit var in_dex:EditText
    lateinit var in_int:EditText
    lateinit var in_wis:EditText
    lateinit var in_crs:EditText
    lateinit var in_poular: RatingBar
    lateinit var image_avatar: ImageView
    var url_avatar:Uri?=null


    lateinit var crear_btn:Button


    private lateinit var db_ref: DatabaseReference
    private lateinit var sto_ref: StorageReference


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_insertar)

        in_name=findViewById(R.id.input_nombre)
        in_raza=findViewById(R.id.input_raza)
        in_str=findViewById(R.id.input_str)
        in_cons=findViewById(R.id.input_cons)
        in_dex=findViewById(R.id.input_dex)
        in_int=findViewById(R.id.input_int)
        in_wis=findViewById(R.id.input_wis)
        in_crs=findViewById(R.id.input_car)
        in_poular=findViewById(R.id.ratin_popu)
        image_avatar=findViewById((R.id.iv_avatar_crear))

        crear_btn=findViewById(R.id.btn_modi_pj)

        db_ref= FirebaseDatabase.getInstance().getReference()
        sto_ref= FirebaseStorage.getInstance().getReference()


    }

    override fun onStart() {
        super.onStart()
        val sdf = SimpleDateFormat("dd/M/yyyy")
        val currentDate = sdf.format(Date())
        var id_generado:String?

        crear_btn.setOnClickListener{
            if(in_name.text.toString().trim().equals("")||
                in_raza.text.toString().trim().equals("")||
                in_str.text.toString().trim().equals("")||
                in_cons.text.toString().trim().equals("")||
                in_dex.text.toString().trim().equals("")||
                in_int.text.toString().trim().equals("")||
                in_wis.text.toString().trim().equals("")||
                in_crs.text.toString().trim().equals("")
                    )
                        {

                Toast.makeText(applicationContext, "Faltan datos del formulario", Toast.LENGTH_SHORT)
                    .show()
            }else if(in_str.text.toString().trim().toIntOrNull()==null||
                    in_str.text.toString().toInt()<=0||
                    in_cons.text.toString().trim().toIntOrNull()==null||
                    in_cons.text.toString().toInt()<=0||
                    in_dex.text.toString().trim().toIntOrNull()==null||
                    in_dex.text.toString().toInt()<=0||
                    in_int.text.toString().trim().toIntOrNull()==null||
                    in_int.text.toString().toInt()<=0||
                    in_wis.text.toString().trim().toIntOrNull()==null||
                    in_wis.text.toString().toInt()<=0||
                    in_crs.text.toString().trim().toIntOrNull()==null||
                    in_crs.text.toString().toInt()<=0
            )
                    {
                Toast.makeText(applicationContext, "Las estadisticas no pueden ser 0, o menores que 0", Toast.LENGTH_SHORT)
                    .show()
            }   else if (url_avatar==null){
                Toast.makeText(applicationContext, "Falta seleccionar un avatar para el heroe", Toast.LENGTH_SHORT).show()
            }else

            {

                GlobalScope.launch(Dispatchers.IO) {
                    if(existe_heroe(in_name.text.toString().trim())){
                        tostadaCorrutina("el heroe ya exite")
                    }else{
                        id_generado=db_ref.child("personaje").child("heroe").push().key

                        val url_avatar_firebase=insertarAvatar(id_generado!!,url_avatar!!)

                        insertarPJ(id_generado!!,
                            in_name.text.toString().trim(),
                            in_raza.text.toString().trim(),
                            in_str.text.toString().toInt(),
                            in_cons.text.toString().toInt(),
                            in_dex.text.toString().toInt(),
                            in_int.text.toString().toInt(),
                            in_wis.text.toString().toInt(),
                            in_crs.text.toString().toInt(),
                            currentDate,
                            in_poular.rating.toFloat(),
                            url_avatar_firebase
                            )

                        tostadaCorrutina("Heroe generado epicamente")
                        val actividad = Intent(applicationContext, MainActivity::class.java)
                        startActivity(actividad)
                    }
                }
            }
        }
        image_avatar.setOnClickListener( {
            obtener_url.launch("image/*")
        })
    }
    private val obtener_url= registerForActivityResult(ActivityResultContracts.GetContent()){
            uri: Uri?->
        when (uri){
            null->Toast.makeText(applicationContext,"No has seleccionado una imagen",Toast.LENGTH_SHORT).show()
            else->{
                url_avatar=uri
                image_avatar.setImageURI(url_avatar)
                Toast.makeText(applicationContext,"Has seleccionado una imagen",Toast.LENGTH_SHORT).show()
            }
        }
    }



    private suspend fun existe_heroe(nombre:String):Boolean{
        var resultado:Boolean?=false


        val semaforo= CountDownLatch(1)

        db_ref.child("personaje")
            .child("heroe")
            .orderByChild("nombre")
            .equalTo(nombre)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if(snapshot.hasChildren()){
                        resultado=true;
                    }
                    semaforo.countDown()

                }

                override fun onCancelled(error: DatabaseError) {
                    println(error.message)
                }
            })

        semaforo.await();

        return resultado!!;
    }

    private suspend fun insertarAvatar(id:String,imagen:Uri):String{
        lateinit var url_avatar_firebase:Uri

        url_avatar_firebase=sto_ref.child("personajes").child("avatar").child(id)
            .putFile(imagen).await().storage.downloadUrl.await()

        return url_avatar_firebase.toString()
    }
    private suspend fun insertarPJ(id:String,nombre:String,raza:String,fuerza:Int,cons:Int, dex:Int, int:Int, wis:Int,crs:Int,creacion:String, Popularidad:Float, url_firebase:String){
        val nuevo_pj= PJ(
            id,
            nombre,
            raza,
            fuerza,
            cons,
            dex,
            int,
            wis,
            crs,
            creacion,
            Popularidad,
            url_firebase


        )
        db_ref.child("personaje").child("heroe").child(id).setValue(nuevo_pj)

    }
    private suspend fun tostadaCorrutina(texto:String){
        runOnUiThread{
            Toast.makeText(
                applicationContext,
                texto,
                Toast.LENGTH_SHORT
            ).show()
        }
    }
}